package Excepciones;

public class ProveedoresException extends Exception{

}
